#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <ctime>

using namespace std;